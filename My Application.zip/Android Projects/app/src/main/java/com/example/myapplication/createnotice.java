package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class createnotice extends AppCompatActivity  {
    private EditText subject;
    //private EditText from;
    private Spinner spinnerfrom;
    private TextView date;
    private EditText about;
    private ImageView submit;
    private ImageView upload;
    private ImageView image;
    private Uri file;
    private FirebaseStorage store;
    DatabaseReference adminnotices;
    private static int Pick_Image=123;
    private ProgressDialog pd;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private String from;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if(requestCode==Pick_Image && resultCode==RESULT_OK && data.getData()!=null)
        {
            file=data.getData();
            try {
                Bitmap map= MediaStore.Images.Media.getBitmap(getContentResolver(),file);
                image.setImageBitmap(map);
                int i = 1;
                image.setVisibility(View.VISIBLE);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }



        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_createnotice);

        pd=new ProgressDialog(this);
        adminnotices= FirebaseDatabase.getInstance().getReference("adminnotices");

        subject=findViewById(R.id.subject);
        //from=(EditText) findViewById(R.id.from);
        spinnerfrom=findViewById(R.id.spinnerfrom);

        List<String> dept=new ArrayList<>();
        dept.add(0,"Choose The Dept");
        dept.add("CSE");
        dept.add("ECE");
        dept.add("EEE");
        dept.add("MECH");
        dept.add("EXAM CELL");

        ArrayAdapter<String> dataAdapter;
        dataAdapter=new ArrayAdapter(this,android.R.layout.simple_spinner_item,dept);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerfrom.setAdapter(dataAdapter);
        spinnerfrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(adapterView.getItemAtPosition(i).equals("Choose The Dept"))
                {
                        from=null;
                }
                else
                {
                    String item=adapterView.getItemAtPosition(i).toString();
                    from=item;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });













        date=(TextView)findViewById(R.id.date);
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal=Calendar.getInstance();
                int year=cal.get(Calendar.YEAR);
                int mon=cal.get(Calendar.MONTH);
                int day=cal.get(Calendar.DAY_OF_MONTH);
                int x=cal.get(Calendar.DATE);
                DatePickerDialog dialog=new DatePickerDialog(createnotice.this,
                        android.R.style.Theme_DeviceDefault_Light_Dialog_NoActionBar_MinWidth,mDateSetListener,year,mon,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();


            }
        });

        mDateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int mon, int day) {
                mon+=1;
                String x=day+"/"+mon+"/"+year;
                date.setText(x);
            }
        };


        about=(EditText)findViewById(R.id.about);
        upload=(ImageView)findViewById(R.id.upload);
        image=(ImageView)findViewById(R.id.image);
        submit=(ImageView) findViewById(R.id.submit);


        store=FirebaseStorage.getInstance();


        upload.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
            @Override
            public void onClick(View view) {
                Intent i=new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);

               startActivityForResult(Intent.createChooser(i,"selectImage"),Pick_Image);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adminnotice();
            }
        });

    }


    private void adminnotice() {

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item);
        String fro=from;
        String sub=subject.getText().toString();
        String ab=about.getText().toString();
        String dat=date.getText().toString();

        if(fro.isEmpty()||sub.isEmpty() || ab.isEmpty() || dat.isEmpty() || file==null)
            Toast.makeText(createnotice.this,"Fill all details",Toast.LENGTH_SHORT).show();
        else
        {
            String id=adminnotices.push().getKey();
            StorageReference mystore=store.getReference().child("adminnotices").child(id).child("poster");
            UploadTask uploadTask=mystore.putFile(file);
            pd.setMessage("Uploading");
            pd.show();
           uploadTask.addOnFailureListener(new OnFailureListener() {
               @Override
               public void onFailure(@NonNull Exception e) {
                Toast.makeText(createnotice.this,"Upload failed",Toast.LENGTH_SHORT).show();
               }
           }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
               @Override
               public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                   pd.dismiss();
                   Toast.makeText(createnotice.this,"Upload Success",Toast.LENGTH_SHORT).show();
                   Intent intent=new Intent(new Intent(getApplicationContext(),adminhome.class));
                   intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                   startActivity(intent);

               }
           });



            String user=FirebaseAuth.getInstance().getCurrentUser().getEmail();
            addadminnotice notice=new addadminnotice(id,sub,fro,dat,ab,user);
            adminnotices.child(id).setValue(notice);
        }

    }


}
