package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class dharaadapter extends RecyclerView.Adapter<dharaadapter.MyviewHolder> {


    private AdapterView.OnItemClickListener listener;
    Context context;
    ArrayList<event> events;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {


        void onDeleteClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public dharaadapter(Context c, ArrayList<event> n)
    {
        context=c;
        events=n;
    }


    @NonNull
    @Override
    public MyviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyviewHolder(LayoutInflater.from(context).inflate(R.layout.cardview,parent,false),mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull MyviewHolder holder, final int position) {

        holder.tit.setText(events.get(position).getTitle());
        holder.fro.setText(events.get(position).getWhen());
        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(context,detailview.class);
                i.putExtra("about",events.get(position).getAbout());
                i.putExtra("date",events.get(position).getWhen());
                i.putExtra("where",events.get(position).getWhere());
                i.putExtra("cate","dharaevents");
                i.putExtra("img",events.get(position).getEventid());
                i.putExtra("tit",events.get(position).getTitle());
                context.startActivity(i);
            }
        });
    }


    @Override
    public int getItemCount() {
        return events.size();
    }

    class MyviewHolder extends  RecyclerView.ViewHolder{

        TextView tit,fro;
        ImageView del;
        LinearLayout card;
        public MyviewHolder(@NonNull View itemView,final OnItemClickListener listener) {
            super(itemView);
            tit=(TextView)itemView.findViewById(R.id.title);
            fro=(TextView)itemView.findViewById(R.id.dept);
            del=(ImageView)itemView.findViewById(R.id.delete);
            card=itemView.findViewById(R.id.card);
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener!=null)
                    {
                        int position=getAdapterPosition();

                        if(position!=RecyclerView.NO_POSITION){
                            listener.onDeleteClick(position);
                        }
                    }
                }
            });

        }



    }

}
