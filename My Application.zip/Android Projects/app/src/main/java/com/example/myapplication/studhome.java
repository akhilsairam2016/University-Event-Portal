package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

public class studhome extends AppCompatActivity {

    private ImageView nadmin;
    private ImageView ndept;
    private ImageView ndhara;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_studhome);

        nadmin=(ImageView)findViewById(R.id.adminnotices);
        ndept=(ImageView)findViewById(R.id.deptnotices);
        ndhara=(ImageView)findViewById(R.id.dharaevents);

        nadmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1=new Intent(studhome.this,adminnotices.class);
                startActivity(i1);
            }
        });

        ndept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i2=new Intent(studhome.this,depthome.class);
                startActivity(i2);
            }
        });

        ndhara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i3=new Intent(studhome.this,dharahome.class);
                startActivity(i3);
            }
        });

    }
}
