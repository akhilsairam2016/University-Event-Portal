package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class studmyadapter extends RecyclerView.Adapter<studmyadapter.MyViewHolder> {

    Context context;
    ArrayList<notice> notices;

    public studmyadapter(Context c,ArrayList<notice> n)
    {
        context=c;
        notices=n;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.studcardview,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder,final int position) {


        holder.tit.setText(notices.get(position).getSubject());
        holder.fro.setText(notices.get(position).getDate());
        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(context,noticedetailview.class);
                i.putExtra("about",notices.get(position).getAbout());
                i.putExtra("date",notices.get(position).getDate());
                i.putExtra("cate","adminnotices");
                i.putExtra("img",notices.get(position).getNoticeid());
                i.putExtra("fro",notices.get(position).getFrom());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return notices.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
        TextView tit,fro;
        ImageView del;
        LinearLayout card;

        public MyViewHolder(View itemview)
        {
            super(itemview);

            tit=(TextView)itemView.findViewById(R.id.stitle);
            fro=(TextView)itemView.findViewById(R.id.sdept);
            card=itemView.findViewById(R.id.studcard);
        }
    }







}
