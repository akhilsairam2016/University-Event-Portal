package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

public class depthome extends AppCompatActivity {

    private ImageView cse;
    private ImageView ece;
    private ImageView eee;
    private ImageView mech;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_depthome);

        cse=(ImageView)findViewById(R.id.csenotices);
        ece=(ImageView)findViewById(R.id.ecenotices);
        eee=(ImageView)findViewById(R.id.eeenotices);
        mech=(ImageView)findViewById(R.id.mechnotices);

        cse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1=new Intent(depthome.this,csenotices.class);
                startActivity(i1);
            }
        });

        ece.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i2=new Intent(depthome.this,ecenotices.class);
                startActivity(i2);
            }
        });


        eee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i3=new Intent(depthome.this,eeenotices.class);
                startActivity(i3);
            }
        });


        mech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i4=new Intent(depthome.this,mechnotices.class);
                startActivity(i4);
            }
        });



    }
}
