package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

public class prachodanahome extends AppCompatActivity {

    private ImageView face;
    private ImageView aavish;
    private ImageView engine;
    private ImageView vidy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_prachodanahome);

        face=(ImageView)findViewById(R.id.face);
        aavish=(ImageView)findViewById(R.id.aavishkara);
        engine=(ImageView)findViewById(R.id.engineum);
        vidy=(ImageView)findViewById(R.id.vidyuth);

        face.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1=new Intent(prachodanahome.this,faceevents.class);
                startActivity(i1);
            }
        });

        vidy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i2=new Intent(prachodanahome.this,vidyevents.class);
                startActivity(i2);
            }
        });
        aavish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i3=new Intent(prachodanahome.this,aavishevents.class);
                startActivity(i3);
            }
        });

        engine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i4=new Intent(prachodanahome.this,engineevents.class);
                startActivity(i4);
            }
        });


    }
}
