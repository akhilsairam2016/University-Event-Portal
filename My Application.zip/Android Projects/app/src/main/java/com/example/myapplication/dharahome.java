package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

public class dharahome extends AppCompatActivity {

    private ImageView prach;
    private ImageView sansk;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_dharahome);

        prach=(ImageView)findViewById(R.id.prachodana);
        sansk=(ImageView)findViewById(R.id.sanskriti);

        prach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1=new Intent(dharahome.this,prachodanahome.class);
                startActivity(i1);
            }
        });

        sansk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i2=new Intent(dharahome.this,sanskritihome.class);
                startActivity(i2);
            }
        });

    }
}
