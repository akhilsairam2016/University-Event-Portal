package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;

public class noticedetailview extends AppCompatActivity {
    private ImageView post;
    private TextView des;
    private TextView ven;

    private TextView time;
    String about,date,from;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_noticedetailview);


        post=(ImageView)findViewById(R.id.Poster1);
        des=findViewById(R.id.descr1);
        ven=findViewById(R.id.venue1);
        time=findViewById(R.id.Time1);


        about=getIntent().getStringExtra("about");
        date=getIntent().getStringExtra("date");
        from=getIntent().getStringExtra("fro");
        String id=getIntent().getStringExtra("img");


        String category=getIntent().getStringExtra("cate");
        StorageReference storage= FirebaseStorage.getInstance().getReference().child(category).child(id).child("poster");
        try {
            final File file= File.createTempFile("image","jpg");
            storage.getFile(file).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                    Bitmap bitmap= BitmapFactory.decodeFile(file.getAbsolutePath());
                    post.setImageBitmap(bitmap);
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }


        des.setText("  "+about);
        time.setText("  "+date);

        ven.setText(" "+from);

    }
}
