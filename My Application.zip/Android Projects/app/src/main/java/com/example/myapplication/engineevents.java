package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class engineevents extends AppCompatActivity {

    Query reference;
    RecyclerView recyclerView;
    ArrayList<event> list;
    studdharaadapter adapter;
    ProgressDialog pd;
    StorageReference sreff;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_engineevents);

        recyclerView=(RecyclerView)findViewById(R.id.enginerecy);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        list=new ArrayList<event>();
        pd=new ProgressDialog(this);
        pd.setMessage("Loading");
        pd.show();
        reference= FirebaseDatabase.getInstance().getReference().child("dharaevents").orderByChild("club").equalTo("ENGINIEUM");
        sreff= FirebaseStorage.getInstance().getReference().child("dharaevents");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull final DataSnapshot dataSnapshot) {
                for(DataSnapshot dataSnapshot1:dataSnapshot.getChildren())
                {
                    event n=dataSnapshot1.getValue(event.class);

                    list.add(n);
                }
                adapter=new studdharaadapter(engineevents.this,list);
                recyclerView.setAdapter(adapter);
                if(list.isEmpty())
                    Toast.makeText(engineevents.this,"No notices",Toast.LENGTH_SHORT).show();
                pd.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                Toast.makeText(engineevents.this,"Something Went Wrong",Toast.LENGTH_SHORT);
            }
        });



    }
}
