package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class studdharaadapter extends RecyclerView.Adapter<studdharaadapter.MyViewHolder> {

    Context context;
    ArrayList<event> events;

    public studdharaadapter(Context c,ArrayList<event> n)
    {
        context=c;
        events=n;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.studdharacard,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder,final int position) {


        holder.when.setText(events.get(position).getTitle());
        holder.where.setText(events.get(position).getWhen());
        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(context,detailview.class);
                i.putExtra("about",events.get(position).getAbout());
                i.putExtra("date",events.get(position).getWhen());
                i.putExtra("cate","dharaevents");
                i.putExtra("img",events.get(position).getEventid());
                i.putExtra("tit",events.get(position).getTitle());
                i.putExtra("where",events.get(position).getWhere());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
        TextView when,where;

        LinearLayout card;

        public MyViewHolder(View itemview)
        {
            super(itemview);

            when=(TextView)itemView.findViewById(R.id.vwhen);
            where=(TextView)itemView.findViewById(R.id.vwhere);
            card=itemView.findViewById(R.id.dharacard);
        }
    }







}
