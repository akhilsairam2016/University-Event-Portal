package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

public class sanskritihome extends AppCompatActivity {
    private ImageView raaga;
    private ImageView abhi;
    private ImageView epic;
    private ImageView narth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_sanskritihome);


        raaga=(ImageView)findViewById(R.id.raga);
        abhi=(ImageView)findViewById(R.id.abhinaya);
        epic=(ImageView)findViewById(R.id.epic);
        narth=(ImageView)findViewById(R.id.narthana);

        narth.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent i1=new Intent(sanskritihome.this,narthanaevents.class);
            startActivity(i1);
            }
        });
        raaga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1=new Intent(sanskritihome.this,raagaevents.class);
                startActivity(i1);
            }
        });
        abhi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1=new Intent(sanskritihome.this,abhinayaevents.class);
                startActivity(i1);
            }
        });
        epic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1=new Intent(sanskritihome.this,epicevents.class);
                startActivity(i1);
            }
        });

    }
}
