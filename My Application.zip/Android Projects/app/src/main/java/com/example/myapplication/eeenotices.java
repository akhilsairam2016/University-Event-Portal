package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class eeenotices extends AppCompatActivity {
    Query reference;
    RecyclerView recyclerView;
    ArrayList<notice> list;
    studmyadapter adapter;
    ProgressDialog pd;
    StorageReference sreff;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_eeenotices);


        recyclerView=(RecyclerView)findViewById(R.id.eeerecy);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        list=new ArrayList<notice>();
        pd=new ProgressDialog(this);
        pd.setMessage("Loading");
        pd.show();
        reference= FirebaseDatabase.getInstance().getReference().child("adminnotices").orderByChild("from").equalTo("EEE");
        sreff= FirebaseStorage.getInstance().getReference().child("adminnotices");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull final DataSnapshot dataSnapshot) {
                for(DataSnapshot dataSnapshot1:dataSnapshot.getChildren())
                {
                    notice n=dataSnapshot1.getValue(notice.class);

                    list.add(n);
                }
                adapter=new studmyadapter(eeenotices.this,list);
                recyclerView.setAdapter(adapter);
                if(list.isEmpty())
                    Toast.makeText(eeenotices.this,"No notices",Toast.LENGTH_SHORT).show();

                pd.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                Toast.makeText(eeenotices.this,"Something Went Wrong",Toast.LENGTH_SHORT);
            }
        });







    }
}
