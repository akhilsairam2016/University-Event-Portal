package com.example.myapplication;

public class addadminnotice {
    String noticeid;
    String subject;
    String from;
    String date;
    String about;
    String user;

    public  addadminnotice()
    {

    }

    public String getNoticeid() {
        return noticeid;
    }

    public String getUser() {
        return user;
    }
    public String getSubject() {
        return subject;
    }

    public String getFrom() {
        return from;
    }

    public String getDate() {
        return date;
    }

    public String getAbout() {
        return about;
    }

    public addadminnotice(String noticeid, String subject, String from, String date, String about,String user) {
        this.noticeid = noticeid;
        this.subject = subject;
        this.from = from;
        this.date = date;
        this.about = about;
        this.user=user;
    }
}
