package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.FileObserver;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class adminhome extends AppCompatActivity {

    ImageView add;
    ImageView logout;
    DatabaseReference reference;
    RecyclerView recyclerView;
    ArrayList<notice> list;
    Myadapter adapter;
    ProgressDialog pd;
    StorageReference sreff;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_adminhome);

        recyclerView=(RecyclerView)findViewById(R.id.myrecycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        list=new ArrayList<notice>();
        pd=new ProgressDialog(this);
        pd.setMessage("Loading");
        pd.show();
        reference= FirebaseDatabase.getInstance().getReference().child("adminnotices");
         sreff=FirebaseStorage.getInstance().getReference().child("adminnotices");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull final DataSnapshot dataSnapshot) {
                for(DataSnapshot dataSnapshot1:dataSnapshot.getChildren())
                {
                    notice n=dataSnapshot1.getValue(notice.class);

                    list.add(n);
                }
                adapter=new Myadapter(adminhome.this,list);
                recyclerView.setAdapter(adapter);
                if(list.isEmpty())
                        Toast.makeText(adminhome.this,"No notices",Toast.LENGTH_SHORT).show();
                adapter.setOnItemClickListener(new Myadapter.OnItemClickListener() {

                    @Override
                    public void onDeleteClick(final int position)
                    {

                        AlertDialog.Builder builder=new AlertDialog.Builder(adminhome.this);

                        builder.setMessage("Are you sure you want to Delete?")
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        notice n=list.get(position);
                                        String selectedkey=n.getNoticeid();
                                        reference.child(selectedkey).removeValue();
                                        sreff.child(selectedkey).child("poster").delete();

                                        overridePendingTransition(0, 0);
                                        getIntent().setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                        startActivity(getIntent());
                                        overridePendingTransition(0, 0);
                                    }
                                }).setNegativeButton("NO",null);
                        AlertDialog alertDialog=builder.create();
                        alertDialog.show();



                    }
                });



                pd.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                Toast.makeText(adminhome.this,"Something Went Wrong",Toast.LENGTH_SHORT);
            }
        });


        add=(ImageView)findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(adminhome.this,createnotice.class));
            }
        });

        logout=findViewById(R.id.logout1);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent i=new Intent(adminhome.this,MainActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
            }
        });



    }


}
