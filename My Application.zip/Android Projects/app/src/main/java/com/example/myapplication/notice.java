package com.example.myapplication;

public class notice {

    private String subject;
    private String from;
    private String about;
    private String date;
    public notice(String subject, String from, String about, String date, String noticeid) {
        this.subject = subject;
        this.from = from;
        this.about = about;
        this.date = date;
        this.noticeid = noticeid;
    }



    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public notice(String subject, String from, String noticeid) {
        this.subject = subject;
        this.from = from;
        this.noticeid = noticeid;
    }

    private String noticeid;

    public String getNoticeid() {
        return noticeid;
    }

    public void setNoticeid(String noticeid) {
        this.noticeid = noticeid;
    }

    public notice(String subject, String from) {
        this.subject = subject;
        this.from = from;
    }

    public notice() {
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }
}
