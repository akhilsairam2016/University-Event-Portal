package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class dharalogin extends AppCompatActivity {
    private EditText email,pass;
    private ImageView sub;
    private ProgressDialog pd;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_dharalogin);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser user=mAuth.getCurrentUser();
       /*if(user!=null) {
            finish();
            startActivity(new Intent(this, amritadharahome.class));
        }*/
        email=(EditText)findViewById(R.id.dlogin);
        pass=(EditText)findViewById(R.id.dpassword);
        sub=(ImageView) findViewById(R.id.dgo);

        pd=new ProgressDialog(this);

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String mail=email.getText().toString();
                String passw=pass.getText().toString();
                if(mail.isEmpty()||passw.isEmpty())
                    Toast.makeText(dharalogin.this,"Please fill all the details",Toast.LENGTH_LONG).show();
                else {
                    pd.setMessage("Logging In");
                    pd.show();
                    mAuth.signInWithEmailAndPassword(mail,passw).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override

                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if(task.isSuccessful()) {
                                startActivity(new Intent(dharalogin.this, amritadharahome.class));
                                pd.dismiss();
                            }
                            else {
                                pd.dismiss();
                                Toast.makeText(dharalogin.this, "Please check the details", Toast.LENGTH_LONG).show();
                            }
                        }
                    });


                }

            }
        });




    }
}
