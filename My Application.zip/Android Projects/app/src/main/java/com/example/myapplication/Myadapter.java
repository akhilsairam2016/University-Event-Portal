package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.security.PrivateKey;
import java.util.ArrayList;

public class Myadapter extends RecyclerView.Adapter<Myadapter.MyviewHolder> {

    private AdapterView.OnItemClickListener listener;
    Context context;
    ArrayList<notice> notices;
    ArrayList<event> events;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {


        void onDeleteClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public Myadapter(Context c, ArrayList<notice> n)
    {
        context=c;
        notices=n;
    }


    @NonNull
    @Override
    public MyviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyviewHolder(LayoutInflater.from(context).inflate(R.layout.cardview,parent,false),mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull MyviewHolder holder, final int position) {

        holder.tit.setText(notices.get(position).getSubject());
        holder.fro.setText(notices.get(position).getFrom());
        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(context,noticedetailview.class);
                i.putExtra("about",notices.get(position).getAbout());
                i.putExtra("date",notices.get(position).getDate());
                i.putExtra("cate","adminnotices");
                i.putExtra("img",notices.get(position).getNoticeid());
                i.putExtra("fro",notices.get(position).getFrom());
                context.startActivity(i);
            }
        });
    }


    @Override
    public int getItemCount() {
        return notices.size();
    }

    class MyviewHolder extends  RecyclerView.ViewHolder{

        TextView tit,fro;
        ImageView del;
        LinearLayout card;
        public MyviewHolder(@NonNull View itemView,final OnItemClickListener listener) {
            super(itemView);
            tit=(TextView)itemView.findViewById(R.id.title);
            fro=(TextView)itemView.findViewById(R.id.dept);
            del=(ImageView)itemView.findViewById(R.id.delete);
            card=itemView.findViewById(R.id.card);
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener!=null)
                    {
                        int position=getAdapterPosition();

                        if(position!=RecyclerView.NO_POSITION){
                            listener.onDeleteClick(position);
                        }
                    }
                }
            });

        }



    }
}
