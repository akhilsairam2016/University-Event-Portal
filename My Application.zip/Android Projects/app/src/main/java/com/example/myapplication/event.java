package com.example.myapplication;

public class event {

    String eventid;
    String title;
    String club;
    String where;
    String when;
    String about;
    String user;
    public event(){

    }
    public event(String club, String where) {

        this.club = club;
        this.where = where;
    }

    public event(String club, String where, String eventid) {
        this.eventid = eventid;
        this.club = club;
        this.where = where;
    }

    public event(String eventid, String club, String where, String when, String about, String user,String title) {
        this.eventid = eventid;
        this.club = club;
        this.where = where;
        this.when = when;
        this.about = about;
        this.user = user;
        this.title=title;
    }

    public void setEventid(String eventid) {
        this.eventid = eventid;
    }

    public void setClub(String club) {
        this.club = club;
    }

    public void setWhere(String where) {
        this.where = where;
    }

    public void setWhen(String when) {
        this.when = when;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getEventid() {
        return eventid;
    }

    public String getClub() {
        return club;
    }

    public String getTitle(){return title;}
    public String getWhere() {
        return where;
    }

    public String getWhen() {
        return when;
    }

    public String getAbout() {
        return about;
    }

    public String getUser() {
        return user;
    }



}
